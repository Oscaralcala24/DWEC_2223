
//Funcion flecha con un alert que tiene un operador ternario
var parImpar = (numero) =>{
    alert(numero % 2 == 0 ? "Es par" : "Es impar");
}

parImpar(prompt("Introduce un numero para saber si es par o impar"));